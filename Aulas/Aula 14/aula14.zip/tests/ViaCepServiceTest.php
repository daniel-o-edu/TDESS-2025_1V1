<?php
use PHPUnit\Framework\TestCase;
use GuzzleHttp\Client;
use GuzzleHttp\Handler\MockHandler;
use GuzzleHttp\HandlerStack;
use GuzzleHttp\Psr7\Response;

class ViaCepServiceTest extends TestCase
{
    public function test_deve_retornar_o_endereco_correto_ao_buscar_por_cep(): void
    {
        // 1. Criamos a resposta "falsa" que simula o formato real do ViaCEP
        $mockResponseBody = json_encode([
            "cep" => "01001-000",
            "logradouro" => "Praça da Sé",
            "bairro" => "Sé",
            "localidade" => "São Paulo",
            "uf" => "SP"
        ]);

        // 2. Injetamos essa resposta no MockHandler do Guzzle
        $mockHandler = new MockHandler([
            new Response(200, [], $mockResponseBody)
        ]);
        
        $handlerStack = HandlerStack::create($mockHandler);
        $client = new Client(['handler' => $handlerStack]);

        // 3. Passamos o cliente "mockado" para o nosso serviço
        $viaCepService = new ViaCepService($client);
        $endereco = $viaCepService->buscar('01001000');

        // 4. Asserção: Garantimos que o nosso código processou o JSON corretamente
        $this->assertEquals('Praça da Sé', $endereco->getLogradouro());
        $this->assertEquals('São Paulo', $endereco->getCidade());
    }
}
?>
