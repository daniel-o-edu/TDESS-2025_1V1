<?php
use PHPUnit\Framework\TestCase;

class UserRepositoryTest extends TestCase
{
    private PDO $db;
    private UserRepository $repository;

    // Executado ANTES de cada teste
    protected function setUp(): void
    {
        // Conecta em um banco exclusivo de testes (ex: SQLite em memória para rapidez)
        $this->db = new PDO('sqlite::memory:');
        $this->db->exec("CREATE TABLE users (id INTEGER PRIMARY KEY, name TEXT, email TEXT)");

        // Inicia a transação para que nada seja salvo definitivamente no disco
        $this->db->beginTransaction();

        $this->repository = new UserRepository($this->db);
    }

    // O teste em si
    public function test_deve_salvar_um_usuario_no_banco_de_dados(): void
    {
        // 1. Dados de teste (simulando um Factory/Seeder)
        $userData = ['name' => 'João Silva', 'email' => 'joao@email.com'];

        // 2. Executa a ação
        $this->repository->save($userData);

        // 3. Asserção: Verifica se o dado realmente foi gravado corretamente
        $savedUser = $this->repository->findByEmail('joao@email.com');
        
        $this->assertNotNull($savedUser);
        $this->assertEquals('João Silva', $savedUser['name']);
    }

    // Executado DEPOIS de cada teste
    protected function tearDown(): void
    {
        // Desfaz tudo o que foi feito no teste, deixando o banco limpo para o próximo
        $this->db->rollBack();
    }
}
?>
