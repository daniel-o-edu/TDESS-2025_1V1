<?php

class Endereco
{
    private string $cep;
    private string $logradouro;
    private string $bairro;
    private string $cidade;
    private string $uf;

    public function __construct(string $cep, string $logradouro, string $bairro, string $cidade, string $uf)
    {
        $this->cep = $cep;
        $this->logradouro = $logradouro;
        $this->bairro = $bairro;
        $this->cidade = $cidade;
        $this->uf = $uf;
    }

    public function getCep(): string
    {
        return $this->cep;
    }

    public function getLogradouro(): string
    {
        return $this->logradouro;
    }

    public function getBairro(): string
    {
        return $this->bairro;
    }

    public function getCidade(): string
    {
        return $this->cidade;
    }

    public function getUf(): string
    {
        return $this->uf;
    }
}