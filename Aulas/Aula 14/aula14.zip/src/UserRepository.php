<?php

class UserRepository
{
    private PDO $db;

    // O construtor recebe a conexão do banco (injeção de dependência)
    public function __construct(PDO $db)
    {
        $this->db = $db;
    }

    /**
     * Salva um novo usuário no banco de dados.
     * * @param array $data Dados do usuário ['name' => '...', 'email' => '...']
     * @return bool Retorna true em caso de sucesso
     */
    public function save(array $data): bool
    {
        $sql = "INSERT INTO users (name, email) VALUES (:name, :email)";
        
        $stmt = $this->db->prepare($sql);
        
        return $stmt->execute([
            ':name'  => $data['name'],
            ':email' => $data['email']
        ]);
    }

    /**
     * Busca um usuário pelo e-mail.
     * * @param string $email
     * @return array|null Retorna os dados do usuário ou null se não encontrar
     */
    public function findByEmail(string $email): ?array
    {
        $sql = "SELECT id, name, email FROM users WHERE email = :email LIMIT 1";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':email' => $email]);
        
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Se não encontrar o usuário, o PDO retorna false. Tratamos para retornar null.
        return $user ?: null;
    }
}