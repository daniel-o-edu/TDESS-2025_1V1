<?php

use GuzzleHttp\Client;
use RuntimeException;

class ViaCepService
{
    private Client $http;

    // Recebemos o cliente HTTP pronto (Injeção de Dependência)
    public function __construct(Client $http)
    {
        $this->http = $http;
    }

    /**
     * Busca o endereço a partir de um CEP.
     * * @param string $cep apenas números ou formatado (ex: 01001000)
     * @return Endereco
     * @throws RuntimeException Se o CEP for inválido ou a requisição falhar
     */
    public function buscar(string $cep): Endereco
    {
        // Remove caracteres especiais caso o usuário digite com hífen
        $cepLimpo = preg_replace('/[^0-9]/', '', $cep);

        try {
            // Faz a requisição HTTP para a URL do ViaCEP
            $response = $this->http->request('GET', "https://viacep.com.br/ws/{$cepLimpo}/json/");
            
            // Decodifica o corpo da resposta JSON em um array associativo
            $dados = json_decode($response->getBody()->getContents(), true);

            // O ViaCEP retorna um campo "erro" caso o CEP não exista na base deles
            if (isset($dados['erro']) && $dados['erro'] === true) {
                throw new RuntimeException("O CEP {$cep} não foi encontrado.");
            }

            // Mapeia os dados do JSON para a nossa classe Endereco
            return new Endereco(
                $dados['cep'] ?? '',
                $dados['logradouro'] ?? '',
                $dados['bairro'] ?? '',
                $dados['localidade'] ?? '', // O ViaCEP chama a cidade de 'localidade'
                $dados['uf'] ?? ''
            );

        } catch (\Exception $e) {
            // Repassa o erro capturado ou falhas de comunicação
            throw new RuntimeException("Erro ao buscar o CEP: " . $e->getMessage());
        }
    }
}